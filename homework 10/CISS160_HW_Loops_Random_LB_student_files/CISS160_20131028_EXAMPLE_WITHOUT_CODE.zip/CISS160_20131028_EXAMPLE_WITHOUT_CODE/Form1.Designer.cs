﻿namespace _20131028_EXAMPLE_STU_STARTER
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.myTxtBox1stDigit = new System.Windows.Forms.TextBox();
            this.myTxtBox2ndDigit = new System.Windows.Forms.TextBox();
            this.myTxtBox3rdDigit = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.myLabelGenerated1stDigit = new System.Windows.Forms.Label();
            this.myLabelGenerated2ndDigit = new System.Windows.Forms.Label();
            this.myLabelGenerated3rdDigit = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.myLabelNumMatchAttempts = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.myListBoxResults = new System.Windows.Forms.ListBox();
            this.myBtnGenRandomNumbers = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.myBtnClearAll = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.myLblCashPayout = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // myTxtBox1stDigit
            // 
            this.myTxtBox1stDigit.Location = new System.Drawing.Point(222, 17);
            this.myTxtBox1stDigit.Name = "myTxtBox1stDigit";
            this.myTxtBox1stDigit.Size = new System.Drawing.Size(23, 20);
            this.myTxtBox1stDigit.TabIndex = 0;
            this.myTxtBox1stDigit.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // myTxtBox2ndDigit
            // 
            this.myTxtBox2ndDigit.Location = new System.Drawing.Point(251, 17);
            this.myTxtBox2ndDigit.Name = "myTxtBox2ndDigit";
            this.myTxtBox2ndDigit.Size = new System.Drawing.Size(23, 20);
            this.myTxtBox2ndDigit.TabIndex = 1;
            this.myTxtBox2ndDigit.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // myTxtBox3rdDigit
            // 
            this.myTxtBox3rdDigit.Location = new System.Drawing.Point(280, 17);
            this.myTxtBox3rdDigit.Name = "myTxtBox3rdDigit";
            this.myTxtBox3rdDigit.Size = new System.Drawing.Size(23, 20);
            this.myTxtBox3rdDigit.TabIndex = 2;
            this.myTxtBox3rdDigit.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(41, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(142, 22);
            this.label1.TabIndex = 3;
            this.label1.Text = "Enter the Winning Number:";
            // 
            // myLabelGenerated1stDigit
            // 
            this.myLabelGenerated1stDigit.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.myLabelGenerated1stDigit.Location = new System.Drawing.Point(223, 84);
            this.myLabelGenerated1stDigit.Name = "myLabelGenerated1stDigit";
            this.myLabelGenerated1stDigit.Size = new System.Drawing.Size(22, 27);
            this.myLabelGenerated1stDigit.TabIndex = 4;
            this.myLabelGenerated1stDigit.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // myLabelGenerated2ndDigit
            // 
            this.myLabelGenerated2ndDigit.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.myLabelGenerated2ndDigit.Location = new System.Drawing.Point(251, 84);
            this.myLabelGenerated2ndDigit.Name = "myLabelGenerated2ndDigit";
            this.myLabelGenerated2ndDigit.Size = new System.Drawing.Size(22, 27);
            this.myLabelGenerated2ndDigit.TabIndex = 5;
            this.myLabelGenerated2ndDigit.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // myLabelGenerated3rdDigit
            // 
            this.myLabelGenerated3rdDigit.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.myLabelGenerated3rdDigit.Location = new System.Drawing.Point(281, 84);
            this.myLabelGenerated3rdDigit.Name = "myLabelGenerated3rdDigit";
            this.myLabelGenerated3rdDigit.Size = new System.Drawing.Size(22, 27);
            this.myLabelGenerated3rdDigit.TabIndex = 6;
            this.myLabelGenerated3rdDigit.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(41, 89);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(168, 22);
            this.label4.TabIndex = 7;
            this.label4.Text = "My Generated Random Number:";
            // 
            // myLabelNumMatchAttempts
            // 
            this.myLabelNumMatchAttempts.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.myLabelNumMatchAttempts.Location = new System.Drawing.Point(251, 117);
            this.myLabelNumMatchAttempts.Name = "myLabelNumMatchAttempts";
            this.myLabelNumMatchAttempts.Size = new System.Drawing.Size(51, 27);
            this.myLabelNumMatchAttempts.TabIndex = 8;
            this.myLabelNumMatchAttempts.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label6
            // 
            this.label6.Location = new System.Drawing.Point(41, 122);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(204, 22);
            this.label6.TabIndex = 9;
            this.label6.Text = "Number of Match attempts @ $1 each:";
            // 
            // myListBoxResults
            // 
            this.myListBoxResults.FormattingEnabled = true;
            this.myListBoxResults.Location = new System.Drawing.Point(44, 208);
            this.myListBoxResults.Name = "myListBoxResults";
            this.myListBoxResults.Size = new System.Drawing.Size(259, 186);
            this.myListBoxResults.TabIndex = 10;
            // 
            // myBtnGenRandomNumbers
            // 
            this.myBtnGenRandomNumbers.Location = new System.Drawing.Point(12, 45);
            this.myBtnGenRandomNumbers.Name = "myBtnGenRandomNumbers";
            this.myBtnGenRandomNumbers.Size = new System.Drawing.Size(326, 23);
            this.myBtnGenRandomNumbers.TabIndex = 11;
            this.myBtnGenRandomNumbers.Text = "Generate Random Number / Try to Match Winning Number";
            this.myBtnGenRandomNumbers.UseVisualStyleBackColor = true;
            this.myBtnGenRandomNumbers.Click += new System.EventHandler(this.myBtnGenRandomNumbers_Click);
            // 
            // label7
            // 
            this.label7.Location = new System.Drawing.Point(41, 189);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(158, 16);
            this.label7.TabIndex = 12;
            this.label7.Text = "History of Match Attempts:";
            // 
            // myBtnClearAll
            // 
            this.myBtnClearAll.Location = new System.Drawing.Point(12, 401);
            this.myBtnClearAll.Name = "myBtnClearAll";
            this.myBtnClearAll.Size = new System.Drawing.Size(326, 23);
            this.myBtnClearAll.TabIndex = 13;
            this.myBtnClearAll.Text = "Clear All";
            this.myBtnClearAll.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(41, 154);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(204, 22);
            this.label2.TabIndex = 15;
            this.label2.Text = "Matching number pays:";
            // 
            // myLblCashPayout
            // 
            this.myLblCashPayout.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.myLblCashPayout.Location = new System.Drawing.Point(251, 149);
            this.myLblCashPayout.Name = "myLblCashPayout";
            this.myLblCashPayout.Size = new System.Drawing.Size(51, 27);
            this.myLblCashPayout.TabIndex = 14;
            this.myLblCashPayout.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(350, 435);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.myLblCashPayout);
            this.Controls.Add(this.myBtnClearAll);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.myBtnGenRandomNumbers);
            this.Controls.Add(this.myListBoxResults);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.myLabelNumMatchAttempts);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.myLabelGenerated3rdDigit);
            this.Controls.Add(this.myLabelGenerated2ndDigit);
            this.Controls.Add(this.myLabelGenerated1stDigit);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.myTxtBox3rdDigit);
            this.Controls.Add(this.myTxtBox2ndDigit);
            this.Controls.Add(this.myTxtBox1stDigit);
            this.Name = "Form1";
            this.Text = "Lottery - Odds are ...";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox myTxtBox1stDigit;
        private System.Windows.Forms.TextBox myTxtBox2ndDigit;
        private System.Windows.Forms.TextBox myTxtBox3rdDigit;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label myLabelGenerated1stDigit;
        private System.Windows.Forms.Label myLabelGenerated2ndDigit;
        private System.Windows.Forms.Label myLabelGenerated3rdDigit;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label myLabelNumMatchAttempts;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ListBox myListBoxResults;
        private System.Windows.Forms.Button myBtnGenRandomNumbers;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button myBtnClearAll;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label myLblCashPayout;

    }
}

