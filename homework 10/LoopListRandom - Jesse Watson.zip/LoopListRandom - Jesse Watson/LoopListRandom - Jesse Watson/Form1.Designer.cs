﻿namespace LoopListRandom___Jesse_Watson
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.myNumber1 = new System.Windows.Forms.TextBox();
            this.myNumber2 = new System.Windows.Forms.TextBox();
            this.myNumber3 = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.winningNumber1 = new System.Windows.Forms.Label();
            this.winningNumber2 = new System.Windows.Forms.Label();
            this.winningNumber3 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.attempts = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.cashPrize = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(27, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(209, 30);
            this.label1.TabIndex = 0;
            this.label1.Text = "Enter Winning Numbers!!!";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // myNumber1
            // 
            this.myNumber1.Location = new System.Drawing.Point(261, 30);
            this.myNumber1.Name = "myNumber1";
            this.myNumber1.Size = new System.Drawing.Size(32, 20);
            this.myNumber1.TabIndex = 1;
            // 
            // myNumber2
            // 
            this.myNumber2.Location = new System.Drawing.Point(299, 30);
            this.myNumber2.Name = "myNumber2";
            this.myNumber2.Size = new System.Drawing.Size(32, 20);
            this.myNumber2.TabIndex = 2;
            // 
            // myNumber3
            // 
            this.myNumber3.Location = new System.Drawing.Point(337, 30);
            this.myNumber3.Name = "myNumber3";
            this.myNumber3.Size = new System.Drawing.Size(32, 20);
            this.myNumber3.TabIndex = 3;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(43, 75);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(326, 23);
            this.button1.TabIndex = 4;
            this.button1.Text = "I\'m Feeling Lucky";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(43, 118);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(193, 23);
            this.label2.TabIndex = 5;
            this.label2.Text = "Actual Winning Numbers!!!";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // winningNumber1
            // 
            this.winningNumber1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.winningNumber1.Location = new System.Drawing.Point(261, 118);
            this.winningNumber1.Name = "winningNumber1";
            this.winningNumber1.Size = new System.Drawing.Size(32, 23);
            this.winningNumber1.TabIndex = 6;
            this.winningNumber1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // winningNumber2
            // 
            this.winningNumber2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.winningNumber2.Location = new System.Drawing.Point(299, 118);
            this.winningNumber2.Name = "winningNumber2";
            this.winningNumber2.Size = new System.Drawing.Size(32, 23);
            this.winningNumber2.TabIndex = 7;
            this.winningNumber2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // winningNumber3
            // 
            this.winningNumber3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.winningNumber3.Location = new System.Drawing.Point(337, 118);
            this.winningNumber3.Name = "winningNumber3";
            this.winningNumber3.Size = new System.Drawing.Size(32, 23);
            this.winningNumber3.TabIndex = 8;
            this.winningNumber3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(43, 170);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(193, 23);
            this.label6.TabIndex = 9;
            this.label6.Text = "Number Of Attempts";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // attempts
            // 
            this.attempts.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.attempts.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.attempts.Location = new System.Drawing.Point(261, 170);
            this.attempts.Name = "attempts";
            this.attempts.Size = new System.Drawing.Size(108, 23);
            this.attempts.TabIndex = 10;
            this.attempts.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(43, 216);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(193, 23);
            this.label3.TabIndex = 11;
            this.label3.Text = "Matching Number Pays";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cashPrize
            // 
            this.cashPrize.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.cashPrize.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cashPrize.Location = new System.Drawing.Point(261, 216);
            this.cashPrize.Name = "cashPrize";
            this.cashPrize.Size = new System.Drawing.Size(108, 23);
            this.cashPrize.TabIndex = 12;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.listBox1);
            this.groupBox1.Location = new System.Drawing.Point(43, 272);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(326, 142);
            this.groupBox1.TabIndex = 13;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "History Of Match Attempts";
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(6, 19);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(314, 108);
            this.listBox1.TabIndex = 0;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(420, 426);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.cashPrize);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.attempts);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.winningNumber3);
            this.Controls.Add(this.winningNumber2);
            this.Controls.Add(this.winningNumber1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.myNumber3);
            this.Controls.Add(this.myNumber2);
            this.Controls.Add(this.myNumber1);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Lottery Game";
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox myNumber1;
        private System.Windows.Forms.TextBox myNumber2;
        private System.Windows.Forms.TextBox myNumber3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label winningNumber1;
        private System.Windows.Forms.Label winningNumber2;
        private System.Windows.Forms.Label winningNumber3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label attempts;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label cashPrize;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ListBox listBox1;
    }
}

