﻿namespace MathLibCircleInfo___Jesse_Watson
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.PleaseEnterCircle = new System.Windows.Forms.Label();
            this.circleDiameter = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.diameter = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.circumference = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.area = new System.Windows.Forms.Label();
            this.clear = new System.Windows.Forms.Button();
            this.closeButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // PleaseEnterCircle
            // 
            this.PleaseEnterCircle.Font = new System.Drawing.Font("Modern No. 20", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PleaseEnterCircle.Location = new System.Drawing.Point(13, 9);
            this.PleaseEnterCircle.Name = "PleaseEnterCircle";
            this.PleaseEnterCircle.Size = new System.Drawing.Size(100, 49);
            this.PleaseEnterCircle.TabIndex = 0;
            this.PleaseEnterCircle.Text = "Please Enter Circle Diameter";
            this.PleaseEnterCircle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // circleDiameter
            // 
            this.circleDiameter.Location = new System.Drawing.Point(12, 70);
            this.circleDiameter.Name = "circleDiameter";
            this.circleDiameter.Size = new System.Drawing.Size(100, 20);
            this.circleDiameter.TabIndex = 1;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(165, 22);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 2;
            this.button1.Text = "Generate";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label1.Font = new System.Drawing.Font("Modern No. 20", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(13, 104);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(100, 23);
            this.label1.TabIndex = 3;
            this.label1.Text = "Diameter";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // diameter
            // 
            this.diameter.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.diameter.Font = new System.Drawing.Font("Modern No. 20", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.diameter.Location = new System.Drawing.Point(162, 104);
            this.diameter.Name = "diameter";
            this.diameter.Size = new System.Drawing.Size(100, 23);
            this.diameter.TabIndex = 4;
            this.diameter.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label2.Font = new System.Drawing.Font("Modern No. 20", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(12, 150);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 23);
            this.label2.TabIndex = 5;
            this.label2.Text = "Circumference";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // circumference
            // 
            this.circumference.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.circumference.Font = new System.Drawing.Font("Modern No. 20", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.circumference.Location = new System.Drawing.Point(162, 150);
            this.circumference.Name = "circumference";
            this.circumference.Size = new System.Drawing.Size(100, 23);
            this.circumference.TabIndex = 6;
            this.circumference.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label3.Font = new System.Drawing.Font("Modern No. 20", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(12, 198);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(100, 23);
            this.label3.TabIndex = 7;
            this.label3.Text = "Area";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // area
            // 
            this.area.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.area.Font = new System.Drawing.Font("Modern No. 20", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.area.Location = new System.Drawing.Point(162, 198);
            this.area.Name = "area";
            this.area.Size = new System.Drawing.Size(100, 23);
            this.area.TabIndex = 8;
            this.area.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // clear
            // 
            this.clear.Location = new System.Drawing.Point(165, 67);
            this.clear.Name = "clear";
            this.clear.Size = new System.Drawing.Size(75, 23);
            this.clear.TabIndex = 9;
            this.clear.Text = "Clear";
            this.clear.UseVisualStyleBackColor = true;
            this.clear.Click += new System.EventHandler(this.clear_Click);
            // 
            // closeButton
            // 
            this.closeButton.Location = new System.Drawing.Point(13, 236);
            this.closeButton.Name = "closeButton";
            this.closeButton.Size = new System.Drawing.Size(249, 23);
            this.closeButton.TabIndex = 10;
            this.closeButton.Text = "Close";
            this.closeButton.UseVisualStyleBackColor = true;
            this.closeButton.Click += new System.EventHandler(this.closeButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 262);
            this.Controls.Add(this.closeButton);
            this.Controls.Add(this.clear);
            this.Controls.Add(this.area);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.circumference);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.diameter);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.circleDiameter);
            this.Controls.Add(this.PleaseEnterCircle);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label PleaseEnterCircle;
        private System.Windows.Forms.TextBox circleDiameter;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label diameter;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label circumference;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label area;
        private System.Windows.Forms.Button clear;
        private System.Windows.Forms.Button closeButton;
    }
}

