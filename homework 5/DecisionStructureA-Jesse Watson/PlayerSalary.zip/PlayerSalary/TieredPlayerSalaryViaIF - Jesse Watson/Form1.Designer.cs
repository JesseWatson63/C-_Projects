﻿namespace TieredPlayerSalaryViaIF___Jesse_Watson
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.calculateButton = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.hits = new System.Windows.Forms.TextBox();
            this.allStarBonus = new System.Windows.Forms.CheckBox();
            this.mvpBonus = new System.Windows.Forms.CheckBox();
            this.lastName = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.firstName = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.playersSalary = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.playersName = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.clearButton = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.bestPlayer = new System.Windows.Forms.Label();
            this.salary = new System.Windows.Forms.Label();
            this.totalHits = new System.Windows.Forms.Label();
            this.tierPay = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.clearButton);
            this.groupBox1.Controls.Add(this.calculateButton);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.hits);
            this.groupBox1.Controls.Add(this.allStarBonus);
            this.groupBox1.Controls.Add(this.mvpBonus);
            this.groupBox1.Controls.Add(this.lastName);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.firstName);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(317, 131);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Players Info";
            // 
            // calculateButton
            // 
            this.calculateButton.Location = new System.Drawing.Point(128, 93);
            this.calculateButton.Name = "calculateButton";
            this.calculateButton.Size = new System.Drawing.Size(87, 32);
            this.calculateButton.TabIndex = 8;
            this.calculateButton.Text = "calculate";
            this.calculateButton.UseVisualStyleBackColor = true;
            this.calculateButton.Click += new System.EventHandler(this.calculateButton_Click);
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(7, 76);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(99, 23);
            this.label3.TabIndex = 7;
            this.label3.Text = "Hits";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // hits
            // 
            this.hits.Location = new System.Drawing.Point(10, 105);
            this.hits.Name = "hits";
            this.hits.Size = new System.Drawing.Size(100, 22);
            this.hits.TabIndex = 6;
            // 
            // allStarBonus
            // 
            this.allStarBonus.AutoSize = true;
            this.allStarBonus.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.allStarBonus.Location = new System.Drawing.Point(235, 51);
            this.allStarBonus.Name = "allStarBonus";
            this.allStarBonus.Size = new System.Drawing.Size(77, 20);
            this.allStarBonus.TabIndex = 5;
            this.allStarBonus.Text = "All Star";
            this.allStarBonus.UseVisualStyleBackColor = true;
            // 
            // mvpBonus
            // 
            this.mvpBonus.AutoSize = true;
            this.mvpBonus.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mvpBonus.Location = new System.Drawing.Point(235, 18);
            this.mvpBonus.Name = "mvpBonus";
            this.mvpBonus.Size = new System.Drawing.Size(59, 20);
            this.mvpBonus.TabIndex = 4;
            this.mvpBonus.Text = "MVP";
            this.mvpBonus.UseVisualStyleBackColor = true;
            // 
            // lastName
            // 
            this.lastName.Location = new System.Drawing.Point(128, 51);
            this.lastName.Name = "lastName";
            this.lastName.Size = new System.Drawing.Size(100, 22);
            this.lastName.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(125, 18);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(103, 27);
            this.label2.TabIndex = 2;
            this.label2.Text = "Last Name";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(7, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(99, 27);
            this.label1.TabIndex = 1;
            this.label1.Text = "First Name";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // firstName
            // 
            this.firstName.Location = new System.Drawing.Point(6, 51);
            this.firstName.Name = "firstName";
            this.firstName.Size = new System.Drawing.Size(100, 22);
            this.firstName.TabIndex = 0;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.playersSalary);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.playersName);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(12, 149);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(317, 158);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Calculated Salary";
            // 
            // playersSalary
            // 
            this.playersSalary.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.playersSalary.Cursor = System.Windows.Forms.Cursors.Default;
            this.playersSalary.Location = new System.Drawing.Point(6, 119);
            this.playersSalary.Name = "playersSalary";
            this.playersSalary.Size = new System.Drawing.Size(305, 27);
            this.playersSalary.TabIndex = 3;
            this.playersSalary.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            this.label5.Location = new System.Drawing.Point(6, 78);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(111, 25);
            this.label5.TabIndex = 2;
            this.label5.Text = "Players Salary";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // playersName
            // 
            this.playersName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.playersName.Location = new System.Drawing.Point(6, 47);
            this.playersName.Name = "playersName";
            this.playersName.Size = new System.Drawing.Size(305, 27);
            this.playersName.TabIndex = 1;
            this.playersName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(7, 18);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(110, 25);
            this.label4.TabIndex = 0;
            this.label4.Text = "Players Name";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(235, 93);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(75, 32);
            this.clearButton.TabIndex = 9;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label8);
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.tierPay);
            this.groupBox3.Controls.Add(this.totalHits);
            this.groupBox3.Controls.Add(this.salary);
            this.groupBox3.Controls.Add(this.bestPlayer);
            this.groupBox3.Font = new System.Drawing.Font("Modern No. 20", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.Location = new System.Drawing.Point(344, 12);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(378, 295);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Top Grossing Salary";
            // 
            // bestPlayer
            // 
            this.bestPlayer.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.bestPlayer.Font = new System.Drawing.Font("Microsoft YaHei UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bestPlayer.Location = new System.Drawing.Point(6, 30);
            this.bestPlayer.Name = "bestPlayer";
            this.bestPlayer.Size = new System.Drawing.Size(366, 29);
            this.bestPlayer.TabIndex = 0;
            this.bestPlayer.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // salary
            // 
            this.salary.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.salary.Font = new System.Drawing.Font("Microsoft YaHei UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.salary.Location = new System.Drawing.Point(208, 76);
            this.salary.Name = "salary";
            this.salary.Size = new System.Drawing.Size(164, 29);
            this.salary.TabIndex = 2;
            this.salary.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // totalHits
            // 
            this.totalHits.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.totalHits.Font = new System.Drawing.Font("Microsoft YaHei UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.totalHits.Location = new System.Drawing.Point(208, 126);
            this.totalHits.Name = "totalHits";
            this.totalHits.Size = new System.Drawing.Size(167, 29);
            this.totalHits.TabIndex = 3;
            this.totalHits.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tierPay
            // 
            this.tierPay.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.tierPay.Font = new System.Drawing.Font("Microsoft YaHei UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tierPay.Location = new System.Drawing.Point(208, 170);
            this.tierPay.Name = "tierPay";
            this.tierPay.Size = new System.Drawing.Size(164, 29);
            this.tierPay.TabIndex = 4;
            this.tierPay.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            this.label6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label6.Font = new System.Drawing.Font("Microsoft YaHei UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(6, 76);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(196, 29);
            this.label6.TabIndex = 5;
            this.label6.Text = "Salary";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label7
            // 
            this.label7.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label7.Font = new System.Drawing.Font("Microsoft YaHei UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(6, 126);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(196, 29);
            this.label7.TabIndex = 6;
            this.label7.Text = "Total Hits";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label8
            // 
            this.label8.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label8.Font = new System.Drawing.Font("Microsoft YaHei UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(6, 170);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(196, 29);
            this.label8.TabIndex = 7;
            this.label8.Text = "Tier Number";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(734, 334);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "Baseball Calculated Salary";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button calculateButton;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox hits;
        private System.Windows.Forms.CheckBox allStarBonus;
        private System.Windows.Forms.CheckBox mvpBonus;
        private System.Windows.Forms.TextBox lastName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox firstName;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label playersSalary;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label playersName;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label bestPlayer;
        private System.Windows.Forms.Label salary;
        private System.Windows.Forms.Label totalHits;
        private System.Windows.Forms.Label tierPay;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
    }
}

