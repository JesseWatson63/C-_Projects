﻿namespace CarsCostComparison___Jesse_Watson
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.car1 = new System.Windows.Forms.Label();
            this.car2 = new System.Windows.Forms.Label();
            this.year = new System.Windows.Forms.Label();
            this.yearCar1 = new System.Windows.Forms.TextBox();
            this.yearCar2 = new System.Windows.Forms.TextBox();
            this.make = new System.Windows.Forms.Label();
            this.makeCar1 = new System.Windows.Forms.TextBox();
            this.makeCar2 = new System.Windows.Forms.TextBox();
            this.model = new System.Windows.Forms.Label();
            this.modelCar1 = new System.Windows.Forms.TextBox();
            this.modelCar2 = new System.Windows.Forms.TextBox();
            this.mpg = new System.Windows.Forms.Label();
            this.mpgCar1 = new System.Windows.Forms.TextBox();
            this.mpgCar2 = new System.Windows.Forms.TextBox();
            this.ipp = new System.Windows.Forms.Label();
            this.ippCar1 = new System.Windows.Forms.TextBox();
            this.ippCar2 = new System.Windows.Forms.TextBox();
            this.arp = new System.Windows.Forms.Label();
            this.arpCar1 = new System.Windows.Forms.TextBox();
            this.arpCar2 = new System.Windows.Forms.TextBox();
            this.aic = new System.Windows.Forms.Label();
            this.aicCar1 = new System.Windows.Forms.TextBox();
            this.aicCar2 = new System.Windows.Forms.TextBox();
            this.fuelCost = new System.Windows.Forms.Label();
            this.fuelCostCar1 = new System.Windows.Forms.Label();
            this.fuelCostCar2 = new System.Windows.Forms.Label();
            this.totalCost = new System.Windows.Forms.Label();
            this.tcCar1 = new System.Windows.Forms.Label();
            this.tcCar2 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.resetCar1 = new System.Windows.Forms.Button();
            this.resetCar2 = new System.Windows.Forms.Button();
            this.resetAll = new System.Windows.Forms.Button();
            this.closeButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // car1
            // 
            this.car1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.car1.Location = new System.Drawing.Point(104, 18);
            this.car1.Name = "car1";
            this.car1.Size = new System.Drawing.Size(66, 23);
            this.car1.TabIndex = 0;
            this.car1.Text = "Car 1";
            this.car1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // car2
            // 
            this.car2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.car2.Location = new System.Drawing.Point(189, 18);
            this.car2.Name = "car2";
            this.car2.Size = new System.Drawing.Size(66, 23);
            this.car2.TabIndex = 1;
            this.car2.Text = "Car 2";
            this.car2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // year
            // 
            this.year.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.year.Location = new System.Drawing.Point(12, 48);
            this.year.Name = "year";
            this.year.Size = new System.Drawing.Size(63, 23);
            this.year.TabIndex = 2;
            this.year.Text = "Year";
            this.year.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // yearCar1
            // 
            this.yearCar1.Location = new System.Drawing.Point(107, 50);
            this.yearCar1.Name = "yearCar1";
            this.yearCar1.Size = new System.Drawing.Size(63, 20);
            this.yearCar1.TabIndex = 3;
            // 
            // yearCar2
            // 
            this.yearCar2.Location = new System.Drawing.Point(209, 48);
            this.yearCar2.Name = "yearCar2";
            this.yearCar2.Size = new System.Drawing.Size(63, 20);
            this.yearCar2.TabIndex = 4;
            // 
            // make
            // 
            this.make.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.make.Location = new System.Drawing.Point(15, 75);
            this.make.Name = "make";
            this.make.Size = new System.Drawing.Size(60, 23);
            this.make.TabIndex = 5;
            this.make.Text = "Make";
            this.make.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // makeCar1
            // 
            this.makeCar1.Location = new System.Drawing.Point(107, 77);
            this.makeCar1.Name = "makeCar1";
            this.makeCar1.Size = new System.Drawing.Size(63, 20);
            this.makeCar1.TabIndex = 6;
            // 
            // makeCar2
            // 
            this.makeCar2.Location = new System.Drawing.Point(209, 74);
            this.makeCar2.Name = "makeCar2";
            this.makeCar2.Size = new System.Drawing.Size(63, 20);
            this.makeCar2.TabIndex = 7;
            // 
            // model
            // 
            this.model.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.model.Location = new System.Drawing.Point(18, 102);
            this.model.Name = "model";
            this.model.Size = new System.Drawing.Size(57, 23);
            this.model.TabIndex = 8;
            this.model.Text = "Model";
            this.model.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // modelCar1
            // 
            this.modelCar1.Location = new System.Drawing.Point(107, 104);
            this.modelCar1.Name = "modelCar1";
            this.modelCar1.Size = new System.Drawing.Size(63, 20);
            this.modelCar1.TabIndex = 9;
            // 
            // modelCar2
            // 
            this.modelCar2.Location = new System.Drawing.Point(209, 103);
            this.modelCar2.Name = "modelCar2";
            this.modelCar2.Size = new System.Drawing.Size(63, 20);
            this.modelCar2.TabIndex = 10;
            // 
            // mpg
            // 
            this.mpg.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mpg.Location = new System.Drawing.Point(15, 129);
            this.mpg.Name = "mpg";
            this.mpg.Size = new System.Drawing.Size(73, 33);
            this.mpg.TabIndex = 11;
            this.mpg.Text = "Published MPG";
            this.mpg.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // mpgCar1
            // 
            this.mpgCar1.Location = new System.Drawing.Point(107, 131);
            this.mpgCar1.Name = "mpgCar1";
            this.mpgCar1.Size = new System.Drawing.Size(63, 20);
            this.mpgCar1.TabIndex = 12;
            // 
            // mpgCar2
            // 
            this.mpgCar2.Location = new System.Drawing.Point(209, 130);
            this.mpgCar2.Name = "mpgCar2";
            this.mpgCar2.Size = new System.Drawing.Size(63, 20);
            this.mpgCar2.TabIndex = 13;
            // 
            // ipp
            // 
            this.ipp.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ipp.Location = new System.Drawing.Point(15, 166);
            this.ipp.Name = "ipp";
            this.ipp.Size = new System.Drawing.Size(73, 52);
            this.ipp.TabIndex = 14;
            this.ipp.Text = "Initial Purchase Price";
            this.ipp.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ippCar1
            // 
            this.ippCar1.Location = new System.Drawing.Point(107, 166);
            this.ippCar1.Name = "ippCar1";
            this.ippCar1.Size = new System.Drawing.Size(63, 20);
            this.ippCar1.TabIndex = 15;
            // 
            // ippCar2
            // 
            this.ippCar2.Location = new System.Drawing.Point(209, 166);
            this.ippCar2.Name = "ippCar2";
            this.ippCar2.Size = new System.Drawing.Size(63, 20);
            this.ippCar2.TabIndex = 16;
            // 
            // arp
            // 
            this.arp.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.arp.Location = new System.Drawing.Point(15, 222);
            this.arp.Name = "arp";
            this.arp.Size = new System.Drawing.Size(73, 49);
            this.arp.TabIndex = 17;
            this.arp.Text = "Annual Repair Price";
            this.arp.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // arpCar1
            // 
            this.arpCar1.Location = new System.Drawing.Point(107, 222);
            this.arpCar1.Name = "arpCar1";
            this.arpCar1.Size = new System.Drawing.Size(63, 20);
            this.arpCar1.TabIndex = 18;
            // 
            // arpCar2
            // 
            this.arpCar2.Location = new System.Drawing.Point(209, 222);
            this.arpCar2.Name = "arpCar2";
            this.arpCar2.Size = new System.Drawing.Size(63, 20);
            this.arpCar2.TabIndex = 19;
            // 
            // aic
            // 
            this.aic.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.aic.Location = new System.Drawing.Point(21, 275);
            this.aic.Name = "aic";
            this.aic.Size = new System.Drawing.Size(67, 51);
            this.aic.TabIndex = 20;
            this.aic.Text = "Annual Insurance Cost";
            this.aic.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // aicCar1
            // 
            this.aicCar1.Location = new System.Drawing.Point(107, 275);
            this.aicCar1.Name = "aicCar1";
            this.aicCar1.Size = new System.Drawing.Size(63, 20);
            this.aicCar1.TabIndex = 21;
            // 
            // aicCar2
            // 
            this.aicCar2.Location = new System.Drawing.Point(209, 275);
            this.aicCar2.Name = "aicCar2";
            this.aicCar2.Size = new System.Drawing.Size(63, 20);
            this.aicCar2.TabIndex = 22;
            // 
            // fuelCost
            // 
            this.fuelCost.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fuelCost.Location = new System.Drawing.Point(15, 340);
            this.fuelCost.Name = "fuelCost";
            this.fuelCost.Size = new System.Drawing.Size(90, 49);
            this.fuelCost.TabIndex = 23;
            this.fuelCost.Text = "Calculated 1 Year Fuel Costs";
            this.fuelCost.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // fuelCostCar1
            // 
            this.fuelCostCar1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.fuelCostCar1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fuelCostCar1.Location = new System.Drawing.Point(107, 340);
            this.fuelCostCar1.Name = "fuelCostCar1";
            this.fuelCostCar1.Size = new System.Drawing.Size(79, 23);
            this.fuelCostCar1.TabIndex = 24;
            this.fuelCostCar1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // fuelCostCar2
            // 
            this.fuelCostCar2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.fuelCostCar2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fuelCostCar2.Location = new System.Drawing.Point(192, 340);
            this.fuelCostCar2.Name = "fuelCostCar2";
            this.fuelCostCar2.Size = new System.Drawing.Size(80, 23);
            this.fuelCostCar2.TabIndex = 25;
            this.fuelCostCar2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // totalCost
            // 
            this.totalCost.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.totalCost.Location = new System.Drawing.Point(18, 393);
            this.totalCost.Name = "totalCost";
            this.totalCost.Size = new System.Drawing.Size(70, 44);
            this.totalCost.TabIndex = 26;
            this.totalCost.Text = "5 Year Total Cost";
            this.totalCost.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tcCar1
            // 
            this.tcCar1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tcCar1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tcCar1.Location = new System.Drawing.Point(107, 393);
            this.tcCar1.Name = "tcCar1";
            this.tcCar1.Size = new System.Drawing.Size(79, 23);
            this.tcCar1.TabIndex = 27;
            this.tcCar1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tcCar2
            // 
            this.tcCar2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tcCar2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tcCar2.Location = new System.Drawing.Point(192, 393);
            this.tcCar2.Name = "tcCar2";
            this.tcCar2.Size = new System.Drawing.Size(80, 23);
            this.tcCar2.TabIndex = 28;
            this.tcCar2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(107, 302);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(165, 23);
            this.button1.TabIndex = 29;
            this.button1.Text = "Calculate Totals";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // resetCar1
            // 
            this.resetCar1.Location = new System.Drawing.Point(107, 436);
            this.resetCar1.Name = "resetCar1";
            this.resetCar1.Size = new System.Drawing.Size(79, 23);
            this.resetCar1.TabIndex = 30;
            this.resetCar1.Text = "Reset Car 1";
            this.resetCar1.UseVisualStyleBackColor = true;
            this.resetCar1.Click += new System.EventHandler(this.resetCar1_Click);
            // 
            // resetCar2
            // 
            this.resetCar2.Location = new System.Drawing.Point(192, 436);
            this.resetCar2.Name = "resetCar2";
            this.resetCar2.Size = new System.Drawing.Size(80, 23);
            this.resetCar2.TabIndex = 31;
            this.resetCar2.Text = "Reset Car 2";
            this.resetCar2.UseVisualStyleBackColor = true;
            this.resetCar2.Click += new System.EventHandler(this.resetCar2_Click);
            // 
            // resetAll
            // 
            this.resetAll.Location = new System.Drawing.Point(15, 436);
            this.resetAll.Name = "resetAll";
            this.resetAll.Size = new System.Drawing.Size(84, 23);
            this.resetAll.TabIndex = 32;
            this.resetAll.Text = "Reset All";
            this.resetAll.UseVisualStyleBackColor = true;
            this.resetAll.Click += new System.EventHandler(this.resetAll_Click);
            // 
            // closeButton
            // 
            this.closeButton.Location = new System.Drawing.Point(24, 473);
            this.closeButton.Name = "closeButton";
            this.closeButton.Size = new System.Drawing.Size(248, 23);
            this.closeButton.TabIndex = 33;
            this.closeButton.Text = "Close";
            this.closeButton.UseVisualStyleBackColor = true;
            this.closeButton.Click += new System.EventHandler(this.closeButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(302, 508);
            this.Controls.Add(this.closeButton);
            this.Controls.Add(this.resetAll);
            this.Controls.Add(this.resetCar2);
            this.Controls.Add(this.resetCar1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.tcCar2);
            this.Controls.Add(this.tcCar1);
            this.Controls.Add(this.totalCost);
            this.Controls.Add(this.fuelCostCar2);
            this.Controls.Add(this.fuelCostCar1);
            this.Controls.Add(this.fuelCost);
            this.Controls.Add(this.aicCar2);
            this.Controls.Add(this.aicCar1);
            this.Controls.Add(this.aic);
            this.Controls.Add(this.arpCar2);
            this.Controls.Add(this.arpCar1);
            this.Controls.Add(this.arp);
            this.Controls.Add(this.ippCar2);
            this.Controls.Add(this.ippCar1);
            this.Controls.Add(this.ipp);
            this.Controls.Add(this.mpgCar2);
            this.Controls.Add(this.mpgCar1);
            this.Controls.Add(this.mpg);
            this.Controls.Add(this.modelCar2);
            this.Controls.Add(this.modelCar1);
            this.Controls.Add(this.model);
            this.Controls.Add(this.makeCar2);
            this.Controls.Add(this.makeCar1);
            this.Controls.Add(this.make);
            this.Controls.Add(this.yearCar2);
            this.Controls.Add(this.yearCar1);
            this.Controls.Add(this.year);
            this.Controls.Add(this.car2);
            this.Controls.Add(this.car1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label car1;
        private System.Windows.Forms.Label car2;
        private System.Windows.Forms.Label year;
        private System.Windows.Forms.TextBox yearCar1;
        private System.Windows.Forms.TextBox yearCar2;
        private System.Windows.Forms.Label make;
        private System.Windows.Forms.TextBox makeCar1;
        private System.Windows.Forms.TextBox makeCar2;
        private System.Windows.Forms.Label model;
        private System.Windows.Forms.TextBox modelCar1;
        private System.Windows.Forms.TextBox modelCar2;
        private System.Windows.Forms.Label mpg;
        private System.Windows.Forms.TextBox mpgCar1;
        private System.Windows.Forms.TextBox mpgCar2;
        private System.Windows.Forms.Label ipp;
        private System.Windows.Forms.TextBox ippCar1;
        private System.Windows.Forms.TextBox ippCar2;
        private System.Windows.Forms.Label arp;
        private System.Windows.Forms.TextBox arpCar1;
        private System.Windows.Forms.TextBox arpCar2;
        private System.Windows.Forms.Label aic;
        private System.Windows.Forms.TextBox aicCar1;
        private System.Windows.Forms.TextBox aicCar2;
        private System.Windows.Forms.Label fuelCost;
        private System.Windows.Forms.Label fuelCostCar1;
        private System.Windows.Forms.Label fuelCostCar2;
        private System.Windows.Forms.Label totalCost;
        private System.Windows.Forms.Label tcCar1;
        private System.Windows.Forms.Label tcCar2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button resetCar1;
        private System.Windows.Forms.Button resetCar2;
        private System.Windows.Forms.Button resetAll;
        private System.Windows.Forms.Button closeButton;
    }
}

