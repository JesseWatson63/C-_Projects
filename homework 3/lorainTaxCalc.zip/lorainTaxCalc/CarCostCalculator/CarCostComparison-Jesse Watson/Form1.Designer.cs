﻿namespace CarCostComparison_Jesse_Watson
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.car2 = new System.Windows.Forms.Label();
            this.car1 = new System.Windows.Forms.Label();
            this.year = new System.Windows.Forms.Label();
            this.yearCar1 = new System.Windows.Forms.TextBox();
            this.yearCar2 = new System.Windows.Forms.TextBox();
            this.make = new System.Windows.Forms.Label();
            this.makeCar1 = new System.Windows.Forms.TextBox();
            this.makeCar2 = new System.Windows.Forms.TextBox();
            this.model = new System.Windows.Forms.Label();
            this.modelCar1 = new System.Windows.Forms.TextBox();
            this.modelCar2 = new System.Windows.Forms.TextBox();
            this.mpg = new System.Windows.Forms.Label();
            this.mpgCar1 = new System.Windows.Forms.TextBox();
            this.mpgCar2 = new System.Windows.Forms.TextBox();
            this.ipp = new System.Windows.Forms.Label();
            this.ippCar1 = new System.Windows.Forms.TextBox();
            this.ippCar2 = new System.Windows.Forms.TextBox();
            this.arp = new System.Windows.Forms.Label();
            this.arpCar1 = new System.Windows.Forms.TextBox();
            this.arpCar2 = new System.Windows.Forms.TextBox();
            this.aic = new System.Windows.Forms.Label();
            this.aicCar1 = new System.Windows.Forms.TextBox();
            this.aicCar2 = new System.Windows.Forms.TextBox();
            this.tfc = new System.Windows.Forms.Label();
            this.tcc = new System.Windows.Forms.Label();
            this.tfcCar1 = new System.Windows.Forms.Label();
            this.tfcCar2 = new System.Windows.Forms.Label();
            this.tccCar1 = new System.Windows.Forms.Label();
            this.tccCar2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // car2
            // 
            this.car2.Location = new System.Drawing.Point(243, 23);
            this.car2.Name = "car2";
            this.car2.Size = new System.Drawing.Size(80, 23);
            this.car2.TabIndex = 0;
            this.car2.Text = "Car 2";
            this.car2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // car1
            // 
            this.car1.Location = new System.Drawing.Point(143, 23);
            this.car1.Name = "car1";
            this.car1.Size = new System.Drawing.Size(84, 23);
            this.car1.TabIndex = 1;
            this.car1.Text = "Car 1";
            this.car1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // year
            // 
            this.year.Location = new System.Drawing.Point(12, 52);
            this.year.Name = "year";
            this.year.Size = new System.Drawing.Size(100, 23);
            this.year.TabIndex = 2;
            this.year.Text = "Year";
            this.year.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // yearCar1
            // 
            this.yearCar1.Location = new System.Drawing.Point(146, 54);
            this.yearCar1.Name = "yearCar1";
            this.yearCar1.Size = new System.Drawing.Size(81, 20);
            this.yearCar1.TabIndex = 3;
            // 
            // yearCar2
            // 
            this.yearCar2.Location = new System.Drawing.Point(246, 54);
            this.yearCar2.Name = "yearCar2";
            this.yearCar2.Size = new System.Drawing.Size(77, 20);
            this.yearCar2.TabIndex = 4;
            // 
            // make
            // 
            this.make.Location = new System.Drawing.Point(15, 93);
            this.make.Name = "make";
            this.make.Size = new System.Drawing.Size(100, 23);
            this.make.TabIndex = 5;
            this.make.Text = "Make";
            this.make.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // makeCar1
            // 
            this.makeCar1.Location = new System.Drawing.Point(146, 95);
            this.makeCar1.Name = "makeCar1";
            this.makeCar1.Size = new System.Drawing.Size(81, 20);
            this.makeCar1.TabIndex = 6;
            // 
            // makeCar2
            // 
            this.makeCar2.Location = new System.Drawing.Point(246, 95);
            this.makeCar2.Name = "makeCar2";
            this.makeCar2.Size = new System.Drawing.Size(77, 20);
            this.makeCar2.TabIndex = 7;
            // 
            // model
            // 
            this.model.Location = new System.Drawing.Point(18, 135);
            this.model.Name = "model";
            this.model.Size = new System.Drawing.Size(97, 23);
            this.model.TabIndex = 8;
            this.model.Text = "Model";
            this.model.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // modelCar1
            // 
            this.modelCar1.Location = new System.Drawing.Point(146, 137);
            this.modelCar1.Name = "modelCar1";
            this.modelCar1.Size = new System.Drawing.Size(81, 20);
            this.modelCar1.TabIndex = 9;
            // 
            // modelCar2
            // 
            this.modelCar2.Location = new System.Drawing.Point(246, 137);
            this.modelCar2.Name = "modelCar2";
            this.modelCar2.Size = new System.Drawing.Size(77, 20);
            this.modelCar2.TabIndex = 10;
            // 
            // mpg
            // 
            this.mpg.Location = new System.Drawing.Point(21, 172);
            this.mpg.Name = "mpg";
            this.mpg.Size = new System.Drawing.Size(91, 29);
            this.mpg.TabIndex = 11;
            this.mpg.Text = "Published miles per gallon";
            this.mpg.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // mpgCar1
            // 
            this.mpgCar1.Location = new System.Drawing.Point(146, 172);
            this.mpgCar1.Name = "mpgCar1";
            this.mpgCar1.Size = new System.Drawing.Size(81, 20);
            this.mpgCar1.TabIndex = 12;
            // 
            // mpgCar2
            // 
            this.mpgCar2.Location = new System.Drawing.Point(246, 171);
            this.mpgCar2.Name = "mpgCar2";
            this.mpgCar2.Size = new System.Drawing.Size(77, 20);
            this.mpgCar2.TabIndex = 13;
            // 
            // ipp
            // 
            this.ipp.Location = new System.Drawing.Point(27, 220);
            this.ipp.Name = "ipp";
            this.ipp.Size = new System.Drawing.Size(100, 27);
            this.ipp.TabIndex = 14;
            this.ipp.Text = "Initial purchase price";
            this.ipp.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ippCar1
            // 
            this.ippCar1.Location = new System.Drawing.Point(146, 220);
            this.ippCar1.Name = "ippCar1";
            this.ippCar1.Size = new System.Drawing.Size(81, 20);
            this.ippCar1.TabIndex = 15;
            // 
            // ippCar2
            // 
            this.ippCar2.Location = new System.Drawing.Point(246, 220);
            this.ippCar2.Name = "ippCar2";
            this.ippCar2.Size = new System.Drawing.Size(77, 20);
            this.ippCar2.TabIndex = 16;
            // 
            // arp
            // 
            this.arp.Location = new System.Drawing.Point(27, 268);
            this.arp.Name = "arp";
            this.arp.Size = new System.Drawing.Size(100, 22);
            this.arp.TabIndex = 17;
            this.arp.Text = "Annual repair cost";
            this.arp.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // arpCar1
            // 
            this.arpCar1.Location = new System.Drawing.Point(146, 268);
            this.arpCar1.Name = "arpCar1";
            this.arpCar1.Size = new System.Drawing.Size(81, 20);
            this.arpCar1.TabIndex = 18;
            // 
            // arpCar2
            // 
            this.arpCar2.Location = new System.Drawing.Point(246, 268);
            this.arpCar2.Name = "arpCar2";
            this.arpCar2.Size = new System.Drawing.Size(77, 20);
            this.arpCar2.TabIndex = 19;
            // 
            // aic
            // 
            this.aic.Location = new System.Drawing.Point(27, 309);
            this.aic.Name = "aic";
            this.aic.Size = new System.Drawing.Size(100, 28);
            this.aic.TabIndex = 20;
            this.aic.Text = "Annual insurance cost";
            this.aic.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // aicCar1
            // 
            this.aicCar1.Location = new System.Drawing.Point(146, 317);
            this.aicCar1.Name = "aicCar1";
            this.aicCar1.Size = new System.Drawing.Size(81, 20);
            this.aicCar1.TabIndex = 21;
            // 
            // aicCar2
            // 
            this.aicCar2.Location = new System.Drawing.Point(246, 317);
            this.aicCar2.Name = "aicCar2";
            this.aicCar2.Size = new System.Drawing.Size(77, 20);
            this.aicCar2.TabIndex = 22;
            // 
            // tfc
            // 
            this.tfc.Location = new System.Drawing.Point(15, 351);
            this.tfc.Name = "tfc";
            this.tfc.Size = new System.Drawing.Size(100, 30);
            this.tfc.TabIndex = 23;
            this.tfc.Text = "Total fuel cost for 1 year";
            this.tfc.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tcc
            // 
            this.tcc.Location = new System.Drawing.Point(15, 385);
            this.tcc.Name = "tcc";
            this.tcc.Size = new System.Drawing.Size(100, 34);
            this.tcc.TabIndex = 26;
            this.tcc.Text = "Total car cost for 5 years";
            this.tcc.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tfcCar1
            // 
            this.tfcCar1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tfcCar1.Location = new System.Drawing.Point(143, 351);
            this.tfcCar1.Name = "tfcCar1";
            this.tfcCar1.Size = new System.Drawing.Size(84, 23);
            this.tfcCar1.TabIndex = 27;
            this.tfcCar1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tfcCar2
            // 
            this.tfcCar2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tfcCar2.Location = new System.Drawing.Point(246, 351);
            this.tfcCar2.Name = "tfcCar2";
            this.tfcCar2.Size = new System.Drawing.Size(77, 23);
            this.tfcCar2.TabIndex = 28;
            this.tfcCar2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tccCar1
            // 
            this.tccCar1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tccCar1.Location = new System.Drawing.Point(143, 385);
            this.tccCar1.Name = "tccCar1";
            this.tccCar1.Size = new System.Drawing.Size(84, 23);
            this.tccCar1.TabIndex = 29;
            this.tccCar1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tccCar2
            // 
            this.tccCar2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tccCar2.Location = new System.Drawing.Point(243, 385);
            this.tccCar2.Name = "tccCar2";
            this.tccCar2.Size = new System.Drawing.Size(80, 23);
            this.tccCar2.TabIndex = 30;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(345, 584);
            this.Controls.Add(this.tccCar2);
            this.Controls.Add(this.tccCar1);
            this.Controls.Add(this.tfcCar2);
            this.Controls.Add(this.tfcCar1);
            this.Controls.Add(this.tcc);
            this.Controls.Add(this.tfc);
            this.Controls.Add(this.aicCar2);
            this.Controls.Add(this.aicCar1);
            this.Controls.Add(this.aic);
            this.Controls.Add(this.arpCar2);
            this.Controls.Add(this.arpCar1);
            this.Controls.Add(this.arp);
            this.Controls.Add(this.ippCar2);
            this.Controls.Add(this.ippCar1);
            this.Controls.Add(this.ipp);
            this.Controls.Add(this.mpgCar2);
            this.Controls.Add(this.mpgCar1);
            this.Controls.Add(this.mpg);
            this.Controls.Add(this.modelCar2);
            this.Controls.Add(this.modelCar1);
            this.Controls.Add(this.model);
            this.Controls.Add(this.makeCar2);
            this.Controls.Add(this.makeCar1);
            this.Controls.Add(this.make);
            this.Controls.Add(this.yearCar2);
            this.Controls.Add(this.yearCar1);
            this.Controls.Add(this.year);
            this.Controls.Add(this.car1);
            this.Controls.Add(this.car2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label car2;
        private System.Windows.Forms.Label car1;
        private System.Windows.Forms.Label year;
        private System.Windows.Forms.TextBox yearCar1;
        private System.Windows.Forms.TextBox yearCar2;
        private System.Windows.Forms.Label make;
        private System.Windows.Forms.TextBox makeCar1;
        private System.Windows.Forms.TextBox makeCar2;
        private System.Windows.Forms.Label model;
        private System.Windows.Forms.TextBox modelCar1;
        private System.Windows.Forms.TextBox modelCar2;
        private System.Windows.Forms.Label mpg;
        private System.Windows.Forms.TextBox mpgCar1;
        private System.Windows.Forms.TextBox mpgCar2;
        private System.Windows.Forms.Label ipp;
        private System.Windows.Forms.TextBox ippCar1;
        private System.Windows.Forms.TextBox ippCar2;
        private System.Windows.Forms.Label arp;
        private System.Windows.Forms.TextBox arpCar1;
        private System.Windows.Forms.TextBox arpCar2;
        private System.Windows.Forms.Label aic;
        private System.Windows.Forms.TextBox aicCar1;
        private System.Windows.Forms.TextBox aicCar2;
        private System.Windows.Forms.Label tfc;
        private System.Windows.Forms.Label tcc;
        private System.Windows.Forms.Label tfcCar1;
        private System.Windows.Forms.Label tfcCar2;
        private System.Windows.Forms.Label tccCar1;
        private System.Windows.Forms.Label tccCar2;
    }
}

